export const isAuthenticated = (): boolean => {
    return !!localStorage.getItem('user');
  };
  
  export const login = (email: string): void => {
    localStorage.setItem('user', email);
  };
  
  export const logout = (): void => {
    localStorage.removeItem('user');
  };
  