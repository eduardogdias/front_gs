
## COMO FUNCIONA A APLICAÇÃO
O usuario entra no nosso site, preenche as informações de quanto gasta de energia, tamanho da área que ele tem disnponivel para aplicar os paineis.
A API irá fazer todos os cálculos necessários para que o usuário fique ciente 100% do quanto ele irá gastar, retorno, investimento e relatórios com as empresas parceiras!

Após o formulário 100% preenchido e a empresa selecionada para prestar o serviço, o usuário terá uma devolutiva diretamente com a empresa.  -->


## Como rodar a API
1- Abra o projeto no Eclipse
2- Clique em "Run as" e depois "Run on Server"
3- Selecione o Tomcat
4- Faça as requisições usando "/rest/{nome_tabela}" após o link da url
