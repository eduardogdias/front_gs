"use client";
import React, { useState, useEffect } from "react";
import Footer from "../Footer/page";
import "./page.css";

const Partnership = () => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    companyName: "",
    companyAddress: "",
    companyPhone: "",
    companyCNPJ: "",
    installationCost: "",
    panelLength: "",
    panelWidth: "",
    panelPower: "",
    panelPrice: "",
  });
  const [empresas, setEmpresas] = useState<any[]>([]);
  const [showPopup, setShowPopup] = useState(false);

  useEffect(() => {
    const storedEmpresas = localStorage.getItem("empresas");
    if (storedEmpresas) {
      setEmpresas(JSON.parse(storedEmpresas));
    }
  }, []);

  const handleInputChange = (e: { target: { name: any; value: any } }) => {
    const { name, value } = e.target;
    let updatedValue = value;

    switch (name) {
      case "companyPhone":
        updatedValue = value.replace(/\D/g, "").slice(0, 12);
        break;
      case "companyCNPJ":
        updatedValue = value.replace(/[^0-9xy]/gi, "").slice(0, 14);
        break;
      case "installationCost":
        updatedValue = `R$${value.replace(/[^0-9]/g, "")}`;
        break;
      case "panelLength":
      case "panelWidth":
      case "panelPower":
        updatedValue = value.replace(/[^0-9m]/gi, "");
        break;
      case "panelPrice":
        updatedValue = `R$${value.replace(/[^0-9]/g, "")}`;
        break;
      default:
        break;
    }

    setFormData({ ...formData, [name]: updatedValue });
  };

  const handleNextStep = () => {
    if (step === 2) {
      const updatedEmpresas = [
        ...empresas,
        {
          nome: formData.companyName,
          endereco: formData.companyAddress,
          telefone: formData.companyPhone,
          cnpj: formData.companyCNPJ,
          custoInstalacao: formData.installationCost,
        },
      ];
      localStorage.setItem("empresas", JSON.stringify(updatedEmpresas));
      setEmpresas(updatedEmpresas);
    }
    setStep(step + 1);
  };

  const handleSubmit = (e: { preventDefault: () => void }) => {
    e.preventDefault();
    setShowPopup(true);
    setTimeout(() => {
      setShowPopup(false);
      setStep(1);
      setFormData({
        companyName: "",
        companyAddress: "",
        companyPhone: "",
        companyCNPJ: "",
        installationCost: "",
        panelLength: "",
        panelWidth: "",
        panelPower: "",
        panelPrice: "",
      });
    }, 3000);
  };

  const [empresaFormData, setEmpresaFormData] = useState({
    nome_empresa: "",
    cnpj: "",
    endereco_empresa: "",
  });

  const handleEmpresaChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setEmpresaFormData({ ...empresaFormData, [name]: value });
  };

  const handleEmpresaSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    
    // Envia os dados da empresa para a API
    try {
      const response = await fetch("http://localhost:8080/ProjetoGsSunecs/rest/empresa", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(empresaFormData),
      });
  
      if (response.ok) {
        alert("Empresa cadastrada com sucesso!");
  
        // Após cadastrar a empresa, vamos buscar todas as empresas para exibir na lista
        const updatedEmpresas = await fetchEmpresas();
        setEmpresas(updatedEmpresas);
      } else {
        alert("Erro ao cadastrar a empresa.");
      }
    } catch (error) {
      console.error("Erro:", error);
      alert("Erro ao conectar com o servidor.");
    }
  };
  
  // Função para buscar todas as empresas cadastradas
  const fetchEmpresas = async () => {
    try {
      const response = await fetch("http://localhost:8080/ProjetoGsSunecs/rest/empresa");
      const data = await response.json();
      return data;
    } catch (error) {
      console.error("Erro ao carregar empresas:", error);
      return [];
    }
  };
  

  return (
    <>
      <section id="Tack">
        <div className="Tack-text">
          <h4 className="textt-h4">Bem-Vindo Parceiro!</h4>
          <h1 className="textt-h1">Você topa mudar o Mundo?</h1>
          <p>
            Seguimos adiante, preencha o formulário e torne-se um parceiro!
          </p>
        </div>
      </section>

      <section className="Tack2">
        <div className="white">
          <div className="advantage-card">
            <div className="icon">🌟</div>
            <h3>Expansão de Mercado</h3>
            <p>
              Ao se tornar nosso parceiro, você terá acesso a novas
              oportunidades de mercado, expandindo sua atuação e aumentando sua
              visibilidade.
            </p>
          </div>
          <div className="advantage-card">
            <div className="icon">🚀</div>
            <h3>Inovação Tecnológica</h3>
            <p>
              Trabalhe ao lado de uma empresa que utiliza as mais recentes
              tecnologias para impulsionar seus negócios para o futuro.
            </p>
          </div>
          <div className="advantage-card">
            <div className="icon">🤝</div>
            <h3>Rede de Colaboração</h3>
            <p>
              Conecte-se a uma ampla rede de parceiros e clientes, criando
              colaborações valiosas e duradouras.
            </p>
          </div>
        </div>
      </section>

      <section className="Tack3">
        <div className="progress-bar">
          <div
            className="progress"
            style={{ width: step === 1 ? "50%" : step === 2 ? "100%" : "0%" }}
          ></div>
        </div>
        <div className="form-container">
          {step === 1 && (
            <form className="form-step">
              <h3>Informações da Empresa</h3>
              <input
                type="text"
                name="companyName"
                placeholder="Nome da Empresa"
                value={formData.companyName}
                onChange={handleInputChange}
                required
              />
              <input
                type="text"
                name="companyAddress"
                placeholder="Endereço da Empresa"
                value={formData.companyAddress}
                onChange={handleInputChange}
                required
              />
              <input
                type="text"
                name="companyPhone"
                placeholder="Telefone da Empresa"
                value={formData.companyPhone}
                onChange={handleInputChange}
                required
              />
              <input
                type="text"
                name="companyCNPJ"
                placeholder="CNPJ da Empresa"
                value={formData.companyCNPJ}
                onChange={handleInputChange}
                required
              />
              <input
                type="text"
                name="installationCost"
                placeholder="Valor de Instalação"
                value={formData.installationCost}
                onChange={handleInputChange}
                required
              />
              <button
                type="button"
                className="next-btn"
                onClick={handleNextStep}
              >
                Próximo
              </button>
            </form>
          )}
          {step === 2 && (
            <form className="form-step" onSubmit={handleSubmit}>
              <h3>Informações dos Painéis</h3>
              <input
                type="text"
                name="panelLength"
                placeholder="Comprimento do Painel"
                value={formData.panelLength}
                onChange={handleInputChange}
                required
              />
              <input
                type="text"
                name="panelWidth"
                placeholder="Largura do Painel"
                value={formData.panelWidth}
                onChange={handleInputChange}
                required
              />
              <input
                type="text"
                name="panelPower"
                placeholder="Potência do Painel"
                value={formData.panelPower}
                onChange={handleInputChange}
                required
              />
              <input
                type="text"
                name="panelPrice"
                placeholder="Preço do Painel"
                value={formData.panelPrice}
                onChange={handleInputChange}
                required
              />
              <button type="submit" className="submit-btn">
                Enviar
              </button>
            </form>
          )}
        </div>
      </section>

      {showPopup && (
        <div className="popup">
          <h1>Bem-Vindo Parceiro!</h1>
        </div>
      )}

    </>
  );
};

export default Partnership;
