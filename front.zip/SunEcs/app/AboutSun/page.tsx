import './page.css';

const AboutSun = () => {
    return (
        <>
            <section id="Back">
                <div className="Container">
                    <h2>Sobre a <span>SunEcs</span>!</h2>
                    <div className="Description">
                        <p>Nós viemos ao mercado com o objetivo de transformar vidas. <br />Queremos ser a nova Meta, o novo significado de <span>Esperança</span>.
                            <br /> O mundo precisa de nós, o futuro começa aqui.</p>
                        <div className="Shadow">
                            <img src="/Mud.jpg" alt="" />
                        </div>
                    </div>
                </div>
            </section>
        </>
    )

}

export default AboutSun;

