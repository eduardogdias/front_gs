"use client"
import Link from 'next/link';
import { useState } from 'react';
import './page.css';

const Evaluation = () => {
  const [isVisible, setIsVisible] = useState(false);

  const handleOpen = () => setIsVisible(true);
  const handleClose = () => setIsVisible(false);

  const [showPopup, setShowPopup] = useState(false);

  const handlePopupOpen = () => setShowPopup(true);
  const handlePopupClose = () => setShowPopup(false);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    window.location.href = "/Diagnostic";
  };

  return (
    <>
    <section id="testimonials">
      <h2>Avaliações de nossos clientes</h2>
      <h3>Quem usa, aprova e comprova resultados</h3>

      <div className="testimonial-cards">
        <div className="testimonial-card">
          <p>
            “Em um ano e meio de experiência com a Sun, de <strong>R$300,00</strong> mensal de Luz, passei para a média de <strong>R$198,00</strong> de Luz, 
            esses números fazem grandes diferenças na minha vida.
          </p>

          <footer>
            <strong>VINÍCIUS TORRESAN</strong>
            <span>Cliente da Sun a 1 ano e meio</span>
          </footer>
        </div>

        <div className="testimonial-card">
          <p>
            “Usando a ferramenta Sun Diagnostic todo santo mês, felizmente, na minha casa estamos economizando incríveis <strong>40%</strong> nos boletos de Luz. 
            Eu confesso que não sei se a minha casa teria tido reformas sem essa economia, mas hoje eu estou comemorando as conquistas que alcançamos com a Sun.”
          </p>

          <footer>
            <strong>MARCOS ANDRADE</strong>
            <span>Cliente da Sun a 9 meses</span>
          </footer>
        </div>
      </div>
<br />
      <button className="review-button" onClick={handleOpen}>
        Avaliar
      </button>
<br />
      {isVisible && (
        <div className="review-box">
          <textarea
            className="review-textarea"
            placeholder="Escreva seu comentário aqui..."
          ></textarea>
          <div className="review-actions">
            <button className="submit-button">Enviar</button>
            <button className="cancel-button" onClick={handleClose}>
              Cancelar
            </button>
          </div>
        </div>
      )}
        <button className="cta-button" onClick={handlePopupOpen}>Faça parte &rarr;</button>
    </section>

    {showPopup && (
        <div className="popup-overlay">
          <div className="popup">
            <button className="close-btn" onClick={handlePopupClose}>
              &times;
            </button>
            <h2>Cadastre-se</h2>
            <form onSubmit={handleSubmit}>
              <label>
                Nome:
                <input type="text" name="nome" required />
              </label>
              <label>
                Email:
                <input type="email" name="email" required />
              </label>
              <label>
                CEP:
                <input type="text" name="cep" required />
              </label>
              <button type="submit" className="submit-btn">
                Cadastrar-se
              </button>
            </form>
          </div>
        </div>
      )}

    </>
  );
};

export default Evaluation;
