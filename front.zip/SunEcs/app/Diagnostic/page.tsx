"use client"
import React, { useEffect } from 'react';
import './page.css'
import Formulario from '../Formulario/page';

const Diagnostic = () => {

  useEffect(() => {
    const navbar = document.getElementById('navbar') as HTMLElement; // Se estiver usando 'getElementById'
      if (navbar) {
        navbar.style.display = 'block';
}

const Navbar = document.getElementById('navbar') as HTMLElement; // Se estiver usando 'getElementById'
if (navbar) {
  navbar.style.display = 'block';
}

    }, 
[]);

  return (
    <>

    <Formulario />

    <div className="diagnostic-container">

        
      <h1 className="page-title">Descubra a Energia Solar</h1>

      <div className="content-container">
        <div className="info-box">
          <h2>Energia Solar</h2>
          <p>
            A energia solar é uma solução sustentável que aproveita os raios do sol para gerar eletricidade, reduzindo
            custos e impactos ambientais.
          </p>
        </div>

        <div className="info-box">
          <h2>Benefícios ao Meio Ambiente</h2>
          <p>
            Ao optar pela energia solar, você ajuda a preservar o meio ambiente, reduzindo as emissões de carbono e
            promovendo um futuro mais verde.
          </p>
        </div>

        <div className="info-box">
          <h2>Sustentabilidade</h2>
          <p>
            Invista em fontes de energia renovável e contribua para um mundo mais sustentável, promovendo o uso de
            recursos naturais de maneira consciente.
          </p>
        </div>
      </div>
    </div>
    
    </>

  );
};

export default Diagnostic;
