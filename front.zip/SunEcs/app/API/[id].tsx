import { useRouter } from "next/router";
import { useEffect, useState } from "react";

const IncluirUsuario = () =>{
    const router = useRouter();
    const { id } = router.query;

    const [usuario, setUsuario] = useState({
        nome: "",
        email: "",
        cep: ""
    });

    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    useEffect(() =>{
        if(id && id !== "novo") {
            fetch(`http://localhost:8080/ProjetoGsSunecs/rest/usuario/${id}`)
            .then((resp) =>{
                if (!resp.ok) {
                    throw new Error("Erro ao buscar o usuário");
                }
                return resp.json();
            })
            .then((data) => {
                setUsuario(data);
                setLoading(false);
            })
            .catch((error) => {
                setError("Erro ao buscar o usuário");
                setLoading(false);
            });
        }
    })
}

export default IncluirUsuario;