"use client";

import styled from "styled-components";
import './page.css';
import { useEffect, useState } from "react";

const DivLista = styled.div`
  width: 70%;
  margin: auto;
  font-family: Arial, sans-serif;

  h1 {
    text-align: center;
  }

  a {
    text-decoration: none;
    padding: 10px 15px;
    margin-bottom: 20px;
    background: yellow;
    color: white;
    display: inline-block;
  }

  table {
    width: 100%;
    margin: auto;
    border-collapse: collapse;
  }

  thead tr {
    background: darkblue;
    color: white;
  }

  thead tr th {
    padding: 10px;
  }

  tbody tr:nth-child(2n) {
    background: #ccc;
  }

  tbody tr td a {
    background: none;
    margin-bottom: 5px;
    color: blue;
  }

  tbody tr td button {
    color: red;
    background: none;
    border: none;
  }

  tfoot tr td {
    text-align: center;
    background: #333;
    color: white;
  }
`;

const ListaUsuarios: React.FC = () => {
  const [usuarios, setUsuarios] = useState([]);

  useEffect(() => {
    fetch("http://localhost:8080/ProjetoGsSunecs/rest/usuario")
      .then((resp) => resp.json())
      .then((resp) => {
        setUsuarios(resp);
      })
      .catch((error) => {
        console.error(error);
      });
  }, []);

  const handleDelete = (id: string) =>{
    fetch("http://localhost:8080/ProjetoGsSunecs/rest/usuario"+id,{
        method: 'DELETE'
    })
    .then(() =>{
        window.location.reload();
    })
    .catch((error) =>{
        console.log(error)
    })
  }

  return (
    <>
      <DivLista>
        <h1>Lista de Usuários</h1>
        <table>
          <thead>
            <tr>
              <th>Nome</th>
              <th>Email</th>
              <th>CEP</th>
              <th>Ação</th>
            </tr>
          </thead>
          <tbody>
            {usuarios.map((usuario: any, index: number) => (
              <tr key={index}>
                <td>{usuario.nome}</td>
                <td>{usuario.email}</td>
                <td>{usuario.cep}</td>
                <td>
                  <a href={`/usuario/${usuario.codigo}`}>Editar</a>
                  <button onClick={() => handleDelete(usuario.codigo)}>Deletar </button>
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr>
              <td colSpan={4}>Total de usuários: {usuarios.length}</td>
            </tr>
          </tfoot>
        </table>
      </DivLista>
    </>
  );
};

export default ListaUsuarios;
