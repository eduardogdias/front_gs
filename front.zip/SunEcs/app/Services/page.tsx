"use client"
import Link from 'next/link';
import { useState } from 'react';
import './page.css'

const Services = () => {

  
  return (
    <>
    <section id='main'>
      <h1>Conheça os produtos da <span>SunEcs</span> </h1>
      <div className="cards">
        <div className="card">
          <h2>Sun Diagnostic</h2>
          <p>
            Nossa ferramenta de cálculo de kWh,
            para gastos médios mensais.
          </p>
          <Link href="/">Conhecer serviço &rarr;</Link>
        </div>

        <div className="card">
          <h2>Sun Evaluation</h2>
          <p>
            Avalie o serviço da Sun.
            Assim você contribui com nossa evolução.
          </p>
          <Link href="#testimonials">Avaliar  &rarr;</Link>
        </div>

        <div className="card">
          <h2>Sun Partnership</h2>
          <p>
            Torne-se um de nossos parceiros, aqueles que ajudam na
            evolução do mundo. Cadastre sua empresa!
          </p>
          <Link href="Partnership">Torne-se Parceiro &rarr;</Link>
        </div>

      </div>
    </section>
    </>
  );
};

export default Services;
