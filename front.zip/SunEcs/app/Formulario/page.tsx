import { useEffect, useState } from "react";
import './page.css'

const Formulario = () => {
  const [step, setStep] = useState(1); // Adicionando o estado "step"
  const [formData, setFormData] = useState({
    nome: "",
    email: "",
    cep: "",
    consumoMensal: "",
    gastoMensal: "",
    largura: "",
    comprimento: "",
    paineis: 2,
    geracaoKWh: "",
    economiaReais: "",
    retornoInvestimento: "",
    custoTotal: "",
    nomeEmpresa: "",
    enderecoEmpresa: "",
    telefoneEmpresa: "",
    cnpjEmpresa: "",
    valorInstalacao: "",
    comprimentoPainel: "",
    larguraPainel: "",
    potencia: "",
    preco: "",
  });

  const [empresas, setEmpresas] = useState<any[]>([]);

  useEffect(() => {
    // Buscar empresas cadastradas
    const fetchEmpresas = async () => {
      try {
        const response = await fetch("http://localhost:8080/ProjetoGsSunecs/rest/empresa");
        const data = await response.json();
        setEmpresas(data); // Atualiza as empresas no estado
      } catch (error) {
        console.error("Erro ao carregar empresas:", error);
      }
    };

    fetchEmpresas();
  }, []); // Carrega as empresas ao montar o componente

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleNext = () => {
    if (step < 5) setStep(step + 1); // Passa para a próxima etapa
  };

  const handlePrevious = () => {
    if (step > 1) setStep(step - 1); // Volta para a etapa anterior
  };

  return (
    <>
      <section className="Post">
        <div className="Tittlee">
          <h1>Preencha o Formulário para o Início do nosso Trabalho!</h1>
        </div>
      </section>
      <div className="form-container">
        <div className="form-header">
          <h1>Formulário de Diagnóstico</h1>
          <div className="progress-bar">
            <div className="progress" style={{ width: `${(step / 5) * 100}%` }}></div>
          </div>
        </div>
        <div className="form-content">
          {step === 1 && (
            <div className="form-step">
              <h2>Usuário</h2>
              <input
                type="text"
                name="nome"
                placeholder="Nome"
                onChange={handleChange}
                className="input-field"
              />
              <input
                type="email"
                name="email"
                placeholder="Email"
                onChange={handleChange}
                className="input-field"
              />
              <input
                type="text"
                name="cep"
                placeholder="CEP"
                onChange={handleChange}
                className="input-field"
              />
              <button className="btn-primary" onClick={handleNext}>
                Próximo
              </button>
            </div>
          )}
          {step === 2 && (
            <div className="form-step">
              <h2>Consulta</h2>
              <input
                type="number"
                name="consumoMensal"
                placeholder="Consumo Mensal (kWh)"
                onChange={handleChange}
                className="input-field"
              />
              <input
                type="number"
                name="gastoMensal"
                placeholder="Gasto Mensal (R$)"
                onChange={handleChange}
                className="input-field"
              />
              <input
                type="number"
                name="largura"
                placeholder="Largura da Área (m)"
                onChange={handleChange}
                className="input-field"
              />
              <input
                type="number"
                name="comprimento"
                placeholder="Comprimento da Área (m)"
                onChange={handleChange}
                className="input-field"
              />
              <div className="form-actions">
                <button className="btn-secondary" onClick={handlePrevious}>
                  Anterior
                </button>
                <button className="btn-primary" onClick={handleNext}>
                  Próximo
                </button>
              </div>
            </div>
          )}
          {step === 3 && (
            <div className="form-step">
              <h2>Resultado</h2>
              <label>Quantidade de Paineis</label>
              <input
                type="number"
                name="paineis"
                value={formData.paineis}
                onChange={handleChange}
                className="input-field"
              />
              <label>Geração (kWh)</label>
              <input
                type="number"
                name="geracaoKWh"
                value={formData.geracaoKWh}
                onChange={handleChange}
                className="input-field"
              />
              <label>Economia (R$)</label>
              <input
                type="number"
                name="economiaReais"
                value={formData.economiaReais}
                onChange={handleChange}
                className="input-field"
              />
              <label>Retorno sobre o Investimento</label>
              <input
                type="number"
                name="retornoInvestimento"
                value={formData.retornoInvestimento}
                onChange={handleChange}
                className="input-field"
              />
              <label>Custo Total (R$)</label>
              <input
                type="number"
                name="custoTotal"
                value={formData.custoTotal}
                onChange={handleChange}
                className="input-field"
              />
              <div className="form-actions">
                <button className="btn-secondary" onClick={handlePrevious}>
                  Anterior
                </button>
                <button className="btn-primary" onClick={handleNext}>
                  Próximo
                </button>
              </div>
            </div>
          )}
          {step === 4 && (
            <div className="form-step">
              <h2>Selecione a Empresa</h2>
              <select
                name="nomeEmpresa"
                value={formData.nomeEmpresa}
                onChange={handleChange}
                className="input-field"
              >
                <option value="">Selecione uma Empresa</option>
                {empresas.map((empresa) => (
                  <option key={empresa.id_empre} value={empresa.nome_empre}>
                    {empresa.nome_empre}
                  </option>
                ))}
              </select>
              <div className="form-actions">
                <button className="btn-secondary" onClick={handlePrevious}>
                  Anterior
                </button>
                <button className="btn-primary" onClick={handleNext}>
                  Próximo
                </button>
              </div>
            </div>
          )}
          {step === 5 && (
            <h2>Concluido 100%</h2>
          )}
        </div>
      </div>
    </>
  );
};

export default Formulario;
