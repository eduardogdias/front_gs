"use client"
import { useState } from 'react';
import Link from "next/link";
import './page.css';

const Navbar = () => {
    const [menuVisible, setMenuVisible] = useState(false);

    const toggleMenu = () => {
        setMenuVisible(!menuVisible);
    };

    return (
        <>
            <header>
                <nav className="navigation">
                    <Link href="#" className="logo">S<span>un</span>Ec<span>s</span></Link>
                    <ul className={`nav-menu ${menuVisible ? 'show' : ''}`}>
                        <li className="nav-item"><Link href="/">Casa</Link></li>
                        <li className="nav-item"><Link href="#Back">SunEcs</Link></li>
                        <li className="nav-item"><Link href="#about">Contato</Link></li>
                        <i className='bx bx-search'></i>
                    </ul>
                    <div className="menu" onClick={toggleMenu}>
                        <span className="bar"></span>
                        <span className="bar"></span>
                        <span className="bar"></span>
                    </div>
                </nav>
            </header>
        </>
    );
}

export default Navbar;
