import './page.css'

const Footer = () => {

    return(
        <>
        <section className="backs">
            <br />
            <h3>Code SunEcs</h3>
            <div className="text">
                <p>Venha para o futuro e veja a nova Meta</p>
                <ul>
                    <li><img className='insta' src="/insta.png" alt="" /></li>
                    <li><img className='youtube' src="/youtube.png" alt="" /></li>
                    <li><img className='linkedin' src="/linkedin.png" alt="" /></li>
                </ul>
            </div>
        </section>
        </>
    )
}

export default Footer;